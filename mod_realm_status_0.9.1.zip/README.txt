Install the Realm Status module as you normally would in the Adminisitration backend installer.
Make sure you enable the module.

Note: This module Requires that allow_url_fopen be enabled in your php.ini
