<?php
/**
 * @package Realm Status Module for joomla 1.5
 * @author Brad Cimbura
 * @copyright (C) 2010- Brad Cimbura
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @link http://soylentcode.com/
**/

echo '<img alt="WoW Server Status for '. $data['realm'] .'" src="' . $data['imageurl'] . '" />';
?>